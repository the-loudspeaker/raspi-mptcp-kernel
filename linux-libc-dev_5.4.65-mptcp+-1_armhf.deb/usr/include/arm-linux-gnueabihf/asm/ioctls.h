/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ASM_ARM_IOCTLS_H
#define __ASM_ARM_IOCTLS_H

#define FIOQSIZE	0x545E

#include <asm-generic/ioctls.h>

#endif
